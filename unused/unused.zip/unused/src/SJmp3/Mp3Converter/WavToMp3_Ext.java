package SJmp3.Mp3Converter;
public class WavToMp3_Ext extends ui.LameUI {
    public static ui.LameUI wt;
    public static void main(String args[]) {
        wt=new ui.LameUI();
    }    
}
